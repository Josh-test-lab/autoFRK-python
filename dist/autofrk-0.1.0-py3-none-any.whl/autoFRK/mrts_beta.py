"""
Title: Multi-Resolution Thin-plate Spline basis function for Spatial Data, and calculate the basis function by using rectangular or spherical coordinates.
Author: Hsu, Yao-Chih
Version: 1140611
Reference: Resolution Adaptive Fixed Rank Kringing by ShengLi Tzeng & Hsin-Cheng Huang
"""

# import modules
import numpy as np
import torch
import torch.nn as nn
from scipy.integrate import quad
from typing import Optional, Union, Any
from autoFRK.utils.logger import setup_logger
from autoFRK.utils.device import setup_device
from autoFRK.utils.utils import to_tensor

# logger config
LOGGER = setup_logger()

# classes
class MRTS(nn.Module):
    def __init__(
        self,
        locs: torch.Tensor, 
        k: int=None, 
        calculate_with_spherical: bool=False,
        standardize: bool=True,
        unbiased_std: bool=False,
        dtype: torch.dtype=torch.float64,
        device: Union[torch.device, str]='cpu'
    ):
        """
        Multi-Resolution Thin-plate Spline Basis Functions
        
        Parameters:
            
        Return:

        """
        super().__init__()
        self.dtype = dtype
        self.device = setup_device(device=device)

        locs = to_tensor(obj   = locs,
                         dtype = dtype,
                         device= device
                         )
        if locs.ndim == 1:
            locs = locs.unsqueeze(1)
        self.locs = locs

        self.N, self.d = self.locs.shape

        # number of basis
        max_k = self.N + self.d
        try:
            if k is None:
                self.k = max_k
                LOGGER.warning(f'Parameter "k" was not set. Default value {self.k} is used.')
            elif 0 < k <= (max_k):
                self.k = k
            else:
                self.k = max_k
                LOGGER.warning(f'Parameter "k" is out of valid range, it should be between 1 to {self.k}. Default value {self.k} is used.')
        except TypeError:
            self.k = max_k
            LOGGER.warning(f'Parameter "k" is not an integer, the type you input is "{type(k).__name__}." Default value {self.k} is used.')

        self.calculate_with_spherical = calculate_with_spherical
        if type(self.calculate_with_spherical) is not bool:
            self.calculate_with_spherical = False
            LOGGER.warning(f'Parameter "calculate_with_spherical" should be a boolean, the type you input is "{type(calculate_with_spherical).__name__}". Default value False is used.')
        elif self.calculate_with_spherical and self.d != 2:
            self.calculate_with_spherical = False
            LOGGER.warning(f'Spherical TPS not implemented for d = {self.d}, only d = 2 is supported. Using rectangular coordinate system instead.')
        
        if self.calculate_with_spherical:
            LOGGER.info(f'Calculate TPS with spherical coordinates.')
        else:
            LOGGER.info(f'Calculate TPS with rectangular coordinates.')

        self.standardize = standardize
        if type(self.standardize) is not bool:
            self.standardize = True
            LOGGER.warning(f'Parameter "standardize" should be a boolean, the type you input is "{type(standardize).__name__}". Default value True is used.')

        self.unbiased_std = unbiased_std
        if type(self.unbiased_std) is not bool:
            self.unbiased_std = False
            LOGGER.warning(f'Parameter "unbiased_std" should be a boolean, the type you input is "{type(unbiased_std).__name__}". Default value False is used.')

    def forward(
        self
    ) -> torch.Tensor:
        """
        Forward pass to compute the basis functions. Constructs the basis functions based on the input locations and parameters.

        Returns:
            A tensor of shape [N, k] representing the basis functions.
        """
        # initialize
        dtype = self.dtype
        device = self.device
        
        # Construct X = [1, x1, x2, ..., xd]
        ones = torch.ones(self.N, 1, dtype=dtype, device=device)
        X = torch.cat([ones, self.locs], dim=1)

        if self.k == 1:
            return ones
        elif self.k <= self.d:
            if self.standardize:
                X[:, 1:self.k] = self._standardize(x            = X[:, 1:self.k],
                                                   unbiased_std = None
                                                   )
            return X[:, :self.k]
        

        # TPS basis
        Phi = self._tps_phi(locs                    = self.locs,
                            calculate_with_spherical= self.calculate_with_spherical,
                            dtype                   = dtype,
                            device                  = device
                            )
        
        try:
            XtX_inv = torch.inverse(X.T @ X)
        except RuntimeError as e:
            LOGGER.warning(f'torch.inverse failed due to {e}, this implies "X.T @ X" didn\'t have inverse. Using torch.linalg.pinv instead.')
            XtX_inv = torch.linalg.pinv(X.T @ X)
        Q = torch.eye(self.N, dtype=dtype, device=device) - X @ XtX_inv @ X.T

        # Eigen-decomposition
        G = Q @ Phi @ Q
        eigenvalues, eigenvectors = torch.linalg.eigh(G)  # ascending order
        idx_desc = torch.argsort(eigenvalues, descending=True)
        eigenvalues = eigenvalues[idx_desc]
        eigenvectors = eigenvectors[:, idx_desc]

        Basis_high = eigenvectors * torch.sqrt(torch.tensor(self.N, dtype=dtype, device=device))
        Basis_low = X

        # Standardize
        if self.standardize:
            Basis_low[:, 1:(self.d + 1)] = self._standardize(x              = Basis_low[:, 1:(self.d + 1)],
                                                             unbiased_std   = None
                                                             )

        F = torch.cat([Basis_low, Basis_high], dim=1)

        # Output k basis
        F = F[:, :self.k]

        return F


# main program
if __name__ == "__main__":
    print("This is the class `MRTS` for autoFRK package. Please import it in your code to use its functionalities.")








