# autoFRK-python

Transfer R package `autoFRK` v1.4.3 (Tzeng S et al., 2021) to a python version.

## References

Tzeng S, Huang H, Wang W, Nychka D, Gillespie C (2021). _autoFRK: Automatic Fixed
  Rank Kriging_. R package version 1.4.3,
  [https://CRAN.R-project.org/package=autoFRK](https://CRAN.R-project.org/package=autoFRK).

Wang, J. W.-T. (n.d.). *autoFRK*. GitHub. Retrieved January 7, 2023, from [https://egpivo.github.io/autoFRK/](https://egpivo.github.io/autoFRK/)
