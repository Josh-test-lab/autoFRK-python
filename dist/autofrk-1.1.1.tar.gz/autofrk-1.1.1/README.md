# autoFRK-python

[![PyPI Version](https://img.shields.io/pypi/v/autoFRK.svg)](https://pypi.org/project/autoFRK/)
[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-darkgreen.svg)](https://github.com/Josh-test-lab/autoFRK-python/blob/main/LICENSE)
[![PyPI Downloads](https://static.pepy.tech/personalized-badge/autofrk?period=total&units=INTERNATIONAL_SYSTEM&left_color=GRAY&right_color=GREEN&left_text=downloads)](https://pepy.tech/projects/autofrk)
[![GitHub stars](https://img.shields.io/github/stars/Josh-test-lab/autoFRK-python.svg?style=social)](https://github.com/Josh-test-lab/autoFRK-python/stargazers)

- **Repository:** [https://github.com/Josh-test-lab/autoFRK-python](https://github.com/Josh-test-lab/autoFRK-python)

`autoFRK-python` is a Python implementation of the R package `autoFRK` v1.4.3 (Tzeng S et al., 2021). `autoFRK` provides a **Resolution Adaptive Fixed Rank Kriging (FRK)** approach for handling regular and irregular spatial data, reducing computational cost through multi-resolution basis functions.


## Features

- Spatial modeling based on multi-resolution basis functions
- Supports single or multiple time points
- Offers approximate or EM-based model estimation
- Suitable for global latitude-longitude data
- Implemented in PyTorch, supporting CPU and GPU (requires PyTorch with CUDA support for GPU)



## Installation

Install via pip:

```bash
pip install autoFRK
```

Install directly from GitHub:

```bash
pip install git+https://github.com/Josh-test-lab/autoFRK-python.git
```

Or clone and install manually:

```bash
git clone https://github.com/Josh-test-lab/autoFRK-python.git
cd autoFRK-python
pip install .
```



## Usage

### 1. Import and Initialize

```python
import torch
from autoFRK import AutoFRK

# Initialize the autoFRK model
model = AutoFRK(dtype=torch.float64, device="cpu")
```

### 2. Model Fitting

```python
# Assume `data` is (n, T) observations (NA allowed) and `loc` is (n, d) spatial coordinates  corresponding to n locations
data = torch.randn(100, 1)  # Example data
loc = torch.rand(100, 2)    # Example 2D coordinates

model_object = model.forward(
    data=data,
    loc=loc,
    maxit=50,
    tolerance=1e-6,
    method="fast",          # "fast" or "EM"
    n_neighbor=3
)

print(result.keys())
# ['M', 's', 'negloglik', 'w', 'V', 'G', 'LKobj']
```

`forward()` returns a dictionary including:

- **M**: ML estimate of *M*.
- **s**: Estimate for the scale parameter of measurement errors.
- **negloglik**: Negative log-likelihood.
- **w**: *K* by *T* matrix with *w[t]* as the *t*-th column.
- **V**: *K* by *K* matrix of the prediction error covariance matrix of *w[t]*.
- **G**: User specified basis function matrix or an automatically generated object from `MRTS`.
- **LKobj**: Not used yet.

### 3. Predicting New Data

```python
# Assume `newloc` contains new spatial coordinates
newloc = torch.rand(20, 2)

pred = model.predict(
    obj=result,
    newloc=newloc,
    se_report=True
)

print(pred['pred.value'].shape)  # Predicted values
print(pred.get('se'))            # Standard errors
```

`predict()` can optionally return standard errors (`se_report=True`). If `obj` is not provided, the most recent `forward()` result is used.

## Settings

- `AutoFRK`

`AutoFRK.forward()` supports various parameters:
| Parameter    | Description                                                           | Default    |
| ------------ | --------------------------------------------------------------------- | ---------- |
| `Data`       | *n* by *T* data matrix (NA allowed) with *z[t]* as the *t*-th column. | (Required) |
| `loc`        | *n* by *d* matrix of coordinates corresponding to *n* locations.      | (Required) |
| `mu`         |                                                                       |            |
| `D`          |                                                                       |            |
| `G`          |                                                                       |            |
| `finescale`  |                                                                       |            |
| `maxit`      |                                                                       |            |
| `tolerance`  |                                                                       |            |
| `maxK`       |                                                                       |            |
| `method`     |                                                                       |            |
| `n_neighbor` |                                                                       |            |
| `maxknot`    |                                                                       |            |

`AutoFRK.predict()` supports various parameters:
| Parameter | Description | Default |
| --------- | ----------- | ------- |
|           |             |         |
|           |             |         |
|           |             |         |
|           |             |         |
|           |             |         |
|           |             |         |
|           |             |         |
|           |             |         |
|           |             |         |
|           |             |         |

- `MRTS`

`MRTS.forward()` supports various parameters:
| Parameter | Description | Default |
| --------- | ----------- | ------- |
|           |             |         |
|           |             |         |
|           |             |         |
|           |             |         |
|           |             |         |
|           |             |         |
|           |             |         |
|           |             |         |
|           |             |         |
|           |             |         |

`MRTS.predict()` supports various parameters:
| Parameter | Description | Default |
| --------- | ----------- | ------- |
|           |             |         |
|           |             |         |
|           |             |         |
|           |             |         |
|           |             |         |
|           |             |         |
|           |             |         |
|           |             |         |
|           |             |         |
|           |             |         |

## Example Code

- `AutoFRK`
```python
import torch
from autoFRK import AutoFRK

# Generate fake data
n, T = 200, 1
data = torch.randn(n, T)
loc = torch.rand(n, 2)

# Initialize model
model = AutoFRK(device="cpu")

# Fit model
res = model.forward(
    data=data,
    loc=loc
)

# Predict new data
newloc = torch.rand(10, 2)
pred = model.predict(
    newloc=newloc
)

print("Predicted values:", pred['pred.value'])
```

- `MRTS`
```python
import torch
from autoFRK import MRTS

```

## Experimental Features

- Spherical coordinate basis function computation
- Gradient tracking (using torch's `requires_grad_()`)


## Authors

- [ShengLi Tzeng](https://math.nsysu.edu.tw/p/405-1183-189657,c959.php?Lang=en) — *Original Paper Author*
- [Hsin-Cheng Huang](http://www.stat.sinica.edu.tw/hchuang/ "Hsin-Cheng Huang") — *Original Paper Author*
- [Wen-Ting Wang](https://www.linkedin.com/in/wen-ting-wang-6083a17b "Wen-Ting Wang") — *R Package Author*
- [Yao-Chih Hsu](https://github.com/Josh-test-lab/) — *Python Package Author*

## Contributors

- [Hao-Yun Huang](https://scholar.google.com/citations?user=AaydI0gAAAAJ&hl=zh-TW) — *Spherical Coordinate Thin Plate Spline Provider*
- [Yi-Xuan Xie](https://github.com/yixuan-dev) — *Python Package Tester*
- [Xuan-Chun Wang](https://github.com/wangxc1117) — *Python Package Tester*

## License

[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-darkgreen.svg)](https://github.com/Josh-test-lab/autoFRK-python/blob/main/LICENSE)
- GPL (>= 3)


## Development and Contribution

- Report bugs or request features on [GitHub issues](https://github.com/Josh-test-lab/autoFRK-python/issues)


## References

- Tzeng S, Huang H, Wang W, Nychka D, Gillespie C (2021). *autoFRK: Automatic Fixed Rank Kriging*. R package version 1.4.3, [https://CRAN.R-project.org/package=autoFRK](https://CRAN.R-project.org/package=autoFRK)
- Wang, J. W.-T. (n.d.). *autoFRK*. GitHub. Retrieved January 7, 2023, from [https://egpivo.github.io/autoFRK/](https://egpivo.github.io/autoFRK/)
- Tzeng, S. & Huang, H.-C. (2018). *Resolution Adaptive Fixed Rank Kriging*. Technometrics. [https://doi.org/10.1080/00401706.2017.1345701](https://doi.org/10.1080/00401706.2017.1345701)
- Nychka, D., Hammerling, D., Sain, S., & Lenssen, N. (2016). *LatticeKrig: Multiresolution Kriging Based on Markov Random Fields*


## Citation

- To cite the Python package `autoFRK-python` in publications use:

```
  Tzeng S, Huang H, Wang W, Hsu Y (2025). _autoFRK-python: Automatic Fixed Rank Kriging. The Python version with PyTorch_. Python package version 1.1.1, 
  <https://pypi.org/project/autoFRK/>.
```

- A BibTeX entry for LaTeX users to cite the Python package is:

```
  @Manual{,
    title = {autoFRK-python: Automatic Fixed Rank Kriging. The Python version with PyTorch},
    author = {ShengLi Tzeng and Hsin-Cheng Huang and Wen-Ting Wang and Yao-Chih Hsu},
    year = {2025},
    note = {Python package version 1.1.1},
    url = {https://pypi.org/project/autoFRK/},
  }
```

- To cite the R package `autoFRK` in publications use:

```
  Tzeng S, Huang H, Wang W, Nychka D, Gillespie C (2021). _autoFRK: Automatic Fixed Rank Kriging_. R package version 1.4.3,
  <https://CRAN.R-project.org/package=autoFRK>.
```

- A BibTeX entry for LaTeX users to cite the R package is:

```
  @Manual{,
    title = {autoFRK: Automatic Fixed Rank Kriging},
    author = {ShengLi Tzeng and Hsin-Cheng Huang and Wen-Ting Wang and Douglas Nychka and Colin Gillespie},
    year = {2021},
    note = {R package version 1.4.3},
    url = {https://CRAN.R-project.org/package=autoFRK},
  }
```

## Release Notes

### v1.1.1

- Fixed a `ValueError` caused by missing `v` in the model object when using the "EM" method.
- Fixed a bug about absent indices in `EM0miss` function when using method "EM" with missing data.
- Fixed a bug in `EM0miss` function that cannot find some variables when using method "EM" with missing data.
- Updated additional functions to fully support `requires_grad`.

### v1.1.0

- Added `dtype` and `device` parameters to `AutoFRK.predict()` and `MRTS.predict()`.
- Added `logger_level` parameter to `AutoFRK.__init__()` and `MRTS.__init__()` (default: 20). Options include `NOTSET`(0), `DEBUG`(10), `INFO`(20), `WARNING`(30), `ERROR`(40), `CRITICAL`(50).
- Enhanced automatic device selection, including MPS support.
- Fixed device assignment issue when `device` is not specified, preventing redundant parameter transfers.

### v1.0.0

- Ported R package `autoFRK` to Python.
